#include "assert.h"

void __assert(const char* func, const char* file, int line, const char* failedexpr) {
    
    if(!func) {

    } else {

    }

    __builtin_unreachable();
}