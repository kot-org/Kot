#pragma once

#ifndef __cplusplus

#define true 1
#define false 0
#define bool _Bool

#else

#define __bool_true_false_are_defined 1

#endif