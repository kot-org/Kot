#pragma once

#include "__config.h"

__BEGIN_DECLS

int putchar(char);
int puts(const char*);

int printf(const char*, ...);

__END_DECLS