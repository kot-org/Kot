#pragma once

typedef __SIZE_TYPE__ size_t;

typedef long long ptrdiff_t;