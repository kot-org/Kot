# borrrdex

My progress following and expanding on the [ponchoOS tutorials](https://www.youtube.com/watch?v=mpPbKEeWIHU&list=PLxN4E629pPnJxCQCLy7E0SQY_zuumOVyZ).

Notable expansions as of Ep. 13:

- PCI Device Discovery and Printing
- Blinking cursor and arrow keys to move it
- Expanded scancode recognition for non-alpha, and JP keyboard
