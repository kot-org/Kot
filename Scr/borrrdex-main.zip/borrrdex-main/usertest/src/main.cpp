#include "stdio.h"

extern "C" int main(int argc, char** argv) {
    puts("Hello, world!\n");

    return 0;
}