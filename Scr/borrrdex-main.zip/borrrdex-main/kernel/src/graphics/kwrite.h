#pragma once

void kwrite(const char* s);
void kprintf(const char* fmt, ...);