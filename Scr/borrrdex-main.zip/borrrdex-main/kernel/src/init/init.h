#pragma once

int bsp_init();