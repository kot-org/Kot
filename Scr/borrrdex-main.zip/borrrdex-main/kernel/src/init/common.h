#pragma once

#ifndef __cplusplus
#error C++ only
#endif

#include <cstdint>

void init_startup_thread(uint32_t arg);