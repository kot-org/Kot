#pragma once

void polltty_init();
int polltty_getchar();
void polltty_putchar(int c);