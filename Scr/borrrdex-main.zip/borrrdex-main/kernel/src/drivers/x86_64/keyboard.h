#pragma once

#ifndef __cplusplus
#error C++ only
#endif

#include <cstdint>

void keyboard_init();
char keyboard_getkey();