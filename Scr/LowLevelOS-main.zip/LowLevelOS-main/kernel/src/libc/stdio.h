#pragma once
#include "stdio/printf.h"
#include "stdio/cstring.h"