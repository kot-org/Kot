#pragma once
#define uint8_Limit 255
#define uint16_Limit 65535
#define uint32_Limit 4294967295
#define uint64_Limit 18446744073709551615
#define rand_max 32767