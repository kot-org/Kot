#pragma once
#include "time/rand.h"