#pragma once
#include "../limits.h"
void srand(int seed);
int rand();