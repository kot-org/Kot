#pragma once

struct Point{
    unsigned int X;
    unsigned int Y;
};