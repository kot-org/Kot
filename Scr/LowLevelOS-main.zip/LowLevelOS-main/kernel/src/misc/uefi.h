#pragma once

struct UEFIFirmware {
	unsigned short* Vendor;
	uint32_t Version;
};