#pragma once
#include "../../io/ports.h"
class Sound{
public:
    void play(long long nFrequence);
    void stop();
};