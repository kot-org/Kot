#include <stdio.h>

int putchar(int c)
{
  // write character to stdout
  return c;
}
