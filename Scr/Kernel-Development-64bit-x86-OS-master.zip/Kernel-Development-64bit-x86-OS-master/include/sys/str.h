/*#ifndef STR_H
#define STR_H

char * strstr(char* str, char* substr);

int strcmp(char *str1,char* str2);

char* strcat(char* str1, char* str2);

size_t strlength (char *str);

char* strcpy(char *dest,char *src);

void *memcpy(void *dest, const void *src, uint64_t n);

#endif
*/
