#ifndef KEYBOARD_H
#define KEYBOARD_H

void keyhandler();
void keyboard_install();

#endif
