#ifndef __AHCINEW_H
#define __AHCINEW_H

void pci_probe();

#endif

