#ifndef TIMER_H
#define TIMER_H

void timer_install();
void timer_handler();
void timer_set();
#endif
