#ifndef __KPRINTF_H
#define __KPRINTF_H

void kprintf(const char *fmt, ...);
void backspace();
void tab();
void nextline();
void clrscr();

#endif
