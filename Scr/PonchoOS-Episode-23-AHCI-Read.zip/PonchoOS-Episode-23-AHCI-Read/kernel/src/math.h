#pragma once

struct Point{
    long X;
    long Y;
};