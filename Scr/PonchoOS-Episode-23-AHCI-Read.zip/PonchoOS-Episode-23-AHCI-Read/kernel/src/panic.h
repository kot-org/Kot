#pragma once

void Panic(const char* panicMessage);